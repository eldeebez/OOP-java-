import java.util.Scanner;
public class RightTriangle{
public static void main(String[]args) {
    Scanner in = new Scanner(System.in);
    int s1, s2, s3;
    System.out.println("enter the side 1");
    s1 = in.nextInt();
    System.out.println("enter the side 2");
    s2 = in.nextInt();
    System.out.println("enter the side 3");
    s3 = in.nextInt();
    if ((s1 * s1) == (s2 * s2) + (s3 * s3))
        System.out.println("its a right triangle and the hypo is the first side which equal " + s1);
    else if ((s2 * s2) == (s1 * s1) + (s3 * s3))
        System.out.println("its a right triangle and the hypo is the second side which equal " + s2);
    else if ((s3 * s3) == (s1 * s1) + (s2 * s2))
        System.out.println("its a right triangle and the hypo is the third side which equal " + s3);
    else
        System.out.println("its not a right triangle");
}
}