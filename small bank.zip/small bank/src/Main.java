public class Main {
    public static void main(String[] args) {
    Bank a1= new Bank();
    a1.insert(4451238,"mohammed",10000);
    a1.deposit(12000);
    a1.withdraw(2000);
    a1.checkBalance();
    System.out.println(a1.toString());
    }
}