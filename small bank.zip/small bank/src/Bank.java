public class Bank {
    private int accountNo;
    private String name;
    private float amount;
    public void insert(int an,String n,float am){
        this.accountNo=an;
        this.name= n;
        this.amount=am;
    }
    public void deposit(float am){
        this.amount=this.amount+am;
    }
    public void withdraw(float am){
        if (amount<am)
            System.out.println("insufficient amount");
        else
            this.amount=this.amount-am;
    }
    public void checkBalance(){
        System.out.println("the balance is "+ this.amount);
    }
    public String toString() {
        return "Bank{" + "accountNo = " + accountNo + ", name = " + name  + ", amount = " + amount + '}';
    }
}
