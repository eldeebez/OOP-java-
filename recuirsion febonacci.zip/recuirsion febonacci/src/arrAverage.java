import java.util.Scanner;
  public class arrAverage {
      public static void main (){
        int numbs[]={1,2,3,4,5,6,7,8,9};
        int sum=0,aver;
        for(int i=0;i<=numbs.length;i++){
        sum = sum + numbs[i];
      }
      aver = sum/numbs.length;
          System.out.println("the average is "+aver);
      }
  }