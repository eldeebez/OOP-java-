import java.util.Scanner;
public class Main {
    static  int small(){
        Scanner in = new Scanner(System.in);
        char close ='q';
        int n1=0,n2,n3;
        int min = n1;
        while(close!='x'){
        switch (close) {
            case 'x':
                break;
            default:
                System.out.println("insert three numbers for the process");
                n1 = in.nextInt();
                n2 = in.nextInt();
                n3 = in.nextInt();

                if (n1 > n2)
                    min = n2;
                else if (n2 > n3)
                    min = n3;
                else
                    System.out.println("numbers are not defined!");
                System.out.println("minimum number is " + min);
                System.out.println("press any key to start\nTo close the comparison press x");
                close=in.next().charAt(0);
        }}
        return min;

    }
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        small();

    }
}