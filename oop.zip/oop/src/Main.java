import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Circle c1= new Circle();
        Circle c2=new Circle();
        c1.setColor("black");
        c1.setRadius(3);
        System.out.println(c1.getArea());
        System.out.println(c1.getCircumference());
        System.out.println(c1.toString());
        c2.setRadius(2);
        c2.setColor("blue");
        System.out.println(c2.getCircumference());
        System.out.println(c2.getArea());
        System.out.println(c2.toString());
    }
}