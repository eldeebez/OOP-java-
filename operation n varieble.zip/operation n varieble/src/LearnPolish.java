import java.util.Scanner;
public class LearnPolish{
    public static void main(String[]args){
        Scanner in = new Scanner(System.in);
        String greet,stairs,window,left;
        System.out.println("enter the polish greeting phrase");
        greet= in.nextLine();
        System.out.println("translate 'stairs' to the polish language");
        stairs= in.next();
        System.out.println("translate 'window' to the polish language");
        window=in.next();
        System.out.println("translate 'left' to the polish language");
        left=in.next();
        System.out.println("Obviously U can use '"+greet+"' for greeting, also U can use '"+stairs+"' to say stairs\n U can use '"+window+"' to express that u saw window, last but not least u can use '"+left+"' if u feel tiered to use '"+stairs+"'");

    }
}