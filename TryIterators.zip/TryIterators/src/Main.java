import java.util.*;

public class Main {
    public static void main(String[] args) {
        Collection<String> col = new ArrayList<>();
        col.add("hasan");
        col.add("ali");
        col.add("loay");
        col.add("deeb");
        Iterator<String> it = col.iterator();

        while (it.hasNext()){
            System.out.println(it.next().toUpperCase(Locale.ROOT) );

        }

    }

}
