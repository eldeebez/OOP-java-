package dsaa.lab01;

import java.util.Scanner;
public class Drawer {
    Scanner in = new Scanner(System.in);
    public static void drawPyramid(int rows) {



        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= (rows - i); j++) {
                System.out.print(".");
            }
            for (int s = 1; s <= (i * 2 - 1); s++) {
                System.out.print("x");
            }
            for (int k = 1; k <= rows - i; k++) {
                System.out.print(".");
            }
            System.out.println();
        }
    }
    public static void drawChristmassTree(int row){

        int w = row*2-1;
        if (row <= 2){
            for (int i = 0; i <= 1; i++) {
                System.out.print(".");
                System.out.print("X");
                System.out.print(".");
                System.out.println();
            }
            System.out.println("XXX");
            System.out.println();
        }else {
            for (int i = 0; i <= 1; i++) {
                for (int j = 0; j < w / 2; j++)
                    System.out.print(".");
                System.out.print("X");
                for (int j = 0; j < w / 2; j++)
                    System.out.print(".");
                System.out.println();
            }
            for (int j = 0; j < (w - 2) / 2; j++)
                System.out.print(".");
            System.out.print("XXX");
            for (int j = 0; j < (w - 2) / 2; j++)
                System.out.print(".");
            System.out.println();
        }
        for (int j = row-3; j >= 0; j--){
            for (int i = 0; i < Math.abs(j-row); i++) {
                for (int k = 0; k < row-i-1; k++){
                    System.out.print(".");
                }
                for (int k = 0; k < 2*i+1; k++){
                    System.out.print("X");
                }
                for (int k = 0; k < row-i-1; k++){
                    System.out.print(".");
                }
                System.out.println();

    }
}
    }


}

