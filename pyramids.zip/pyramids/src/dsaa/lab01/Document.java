package dsaa.lab01;

import java.util.Scanner;

public class Document {
    public static void loadDocument(String name, Scanner scan) {
        String line = scan.nextLine();
        String lines = "";
        while (!line.equals("eod") || line == "") {
            lines += line + " ";
            line = scan.nextLine();
        }
        String[] identifiers = lines.split(" ");
        for(String identifier : identifiers){
            if(identifier.toLowerCase().startsWith("link=")){
                if(correctLink(identifier)){
                    System.out.println(identifier.substring(5, identifier.length()).toLowerCase());
                }
            }
        }

    }

    // accepted only small letters, capitalic letter, digits nad '_' (but not on the begin)
    public static boolean correctLink(String link) {
        link = link.substring(5, link.length());
        char[] symbols = link.toCharArray();
        boolean correct = false;
        if(symbols.length != 0){
            if(Character.isLetter(symbols[0])){
                correct = true;
                for(char x : symbols){
                    if(!Character.isLetterOrDigit(x) && x != '_'){
                        correct = false;
                    }
                }
            }
        }

        if(correct){
            return true;
        }
        return false;
    }

}
