public class DailyEmployee extends Employee {
    private float WorkDayPrice,DaysNum;

    public float getWorkDayPrice() {
        return WorkDayPrice;
    }

    public void setWorkDayPrice(float workDayPrice) {
        WorkDayPrice = workDayPrice;
    }

    public float getDailyRate() {
        return DaysNum;
    }

    public void setDailyRate(int dailyRate) {
        DaysNum = dailyRate;
    }
    @Override
    public float getSalary(){
        return super.getSalary()+WorkDayPrice*DaysNum;
    }

    public DailyEmployee(String name, String address, String department, String email,int salary, float workDayPrice, int dailyRate) {
        super(name, address, department, email, salary);
        WorkDayPrice = workDayPrice;
        DaysNum = dailyRate;
    }
}
