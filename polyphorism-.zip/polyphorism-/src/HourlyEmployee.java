public class HourlyEmployee extends Employee {
    private float WorkHourPrice,HoursNum;

    public float getWorkHourPrice() {
        return WorkHourPrice;
    }

    public void setWorkHourPrice(float workHourPrice) {
        WorkHourPrice = workHourPrice;
    }

    public float getHourlyRate() {
        return HoursNum;
    }

    public void setHourlyRate(float hourlyRate) {
        this.HoursNum = hourlyRate;
    }
    @Override
    public float getSalary() {
        return super.getSalary()+WorkHourPrice*HoursNum;
    }



    public HourlyEmployee(String name, String address, String department, String email,int salary, float workHourPrice, float hourlyRate) {
        super(name, address, department, email,salary);
        this.WorkHourPrice = workHourPrice;
        this.HoursNum = hourlyRate;
    }
}
