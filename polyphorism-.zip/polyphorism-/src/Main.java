
public class Main {
    public static void main(String [] args){
        Employee E1 = new HourlyEmployee("ali","doha","It","a.com", 0, 20,75);
        Employee E2 = new MonthlyEmployee("ezz","dubai","finance","e.com",4000,200);
        Employee E3 = new DailyEmployee("Deeb","Doha","Cyper Security","a.gmail.com",0,190,26);
        System.out.println("E1 Salary = "+ E1.getSalary()+"\nE2 Salary = "+ E2.getSalary());
        System.out.println("E3 Salary = "+ E3.getSalary());
    }
}
